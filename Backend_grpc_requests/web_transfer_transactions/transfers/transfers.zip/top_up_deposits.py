import uuid
import grpc
import json
import time
import sys
sys.path.append('C:/project_kicb/Backend_grpc_requests')
import protofile_pb2 as webTransferApi_pb2
import protofile_pb2_grpc as webTransferApi_pb2_grpc

def get_session_data():
    with open('C:/project_kicb/Backend_grpc_requests/web_transfer_transactions/data/session_data.json', 'r') as file:
        session_data = json.load(file)
    return session_data

def make_deposit(request, metadata):
    print(f"Отправка запроса: {request.code}")
    print(f"Данные запроса: {request.data}")
    print(f"Метаданные: {metadata}")
    
    with grpc.secure_channel(
            'newibanktest.kicb.net:443',
            grpc.ssl_channel_credentials(),
            options=[('grpc.enable_http_proxy', 0),
                    ('grpc.keepalive_timeout_ms', 10000)]
    ) as channel:
        client = webTransferApi_pb2_grpc.WebTransferApiStub(channel)
        response = client.makeWebTransfer(request, metadata=metadata)
        print(f"Получен ответ: {response}")
        return response

def create_deposit():
    metadata = (
        ('refid', str(uuid.uuid1())),
        ('sessionkey', get_session_data()['session_key']),
        ('device-type', 'ios'),
        ('user-agent-c', '12; iPhone12MaxProDan'),
    )
    
    deposit_data = {
        "depositType": "Savings deposit",
        "depositId": 1531,
        "mainIntType": "B",
        "amount": "5000",
        "ccy": "KGS",
        "rate": "4.5",
        "accountDebitId": 10954,
        "termOfDeposit": "3",
        "childName": "",
        "childBirthdate": "",
        "files": [],
        "productType": "makeDepositApplication",
        "requestId": f"IB{int(time.time() * 1000)}",
        "accountIdDebit": 10954,
        "amountDebit": "5000",
        "operationId": str(uuid.uuid4()),
        "txnId": None
    }

    request = webTransferApi_pb2.IncomingWebTransfer(
        code="MAKE_DEPOSIT",
        data=json.dumps(deposit_data)
    )
    
    response = make_deposit(request, metadata)
    print("Создание депозита завершено")
    return response, deposit_data

def confirm_deposit(operation_id: str):
    metadata = (
        ('refid', str(uuid.uuid1())),
        ('sessionkey', get_session_data()['session_key']),
        ('device-type', 'ios'),
        ('user-agent-c', '12; iPhone12MaxProDan'),
    )

    confirm_data = {
        "operationId": operation_id,
        "otp": "111111"
    }

    request = webTransferApi_pb2.IncomingWebTransfer(
        code="CONFIRM_TRANSFER",
        data=json.dumps(confirm_data)
    )

    response = make_deposit(request, metadata)
    print("Подтверждение депозита завершено")
    return response

def execute_deposit():
    print("\n=== Начало создания депозита ===")
    
    # Создаем депозит
    deposit_response, deposit_data = create_deposit()
    print(f"\nРезультат создания депозита: {deposit_response}")
    
    # Ждем 3 секунды
    print("\nОжидание 3 секунд...")
    time.sleep(3)
    
    # Подтверждаем депозит
    confirm_response = confirm_deposit(deposit_data["operationId"])
    print(f"\nРезультат подтверждения: {confirm_response}")
    
    return {
        "deposit_response": deposit_response,
        "confirm_response": confirm_response
    }

if __name__ == "__main__":
    try:
        result = execute_deposit()
        print("\n=== Результат выполнения ===")
        print(result)
    except Exception as e:
        print(f"\nОшибка: {str(e)}")
